@echo off
cd /d "%~dp0"
if exist "..\.venv\Scripts\python.exe" (
  "..\.venv\Scripts\python.exe" demo\server.py
) else if exist ".venv\Scripts\python.exe" (
  ".venv\Scripts\python.exe" demo\server.py
) else (
  python demo\server.py
)
pause
